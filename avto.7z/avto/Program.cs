﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

class Car
{
    private double fuelLevel;
    private double fuelConsumption;
    private bool isRunning;
    private double mileage; // Поле для отслеживания общего пробега

    public Car()
    {
        fuelLevel = 0;
        fuelConsumption = 0;
        isRunning = false;
        mileage = 0;
    }

    public void FillTank()
    {
        Console.WriteLine ("Введите объем топлива для заправки (в литрах): ");
        double fuelToAdd = double.Parse(Console.ReadLine());
        fuelLevel += fuelToAdd;
        Console.WriteLine($"Бак заправлен. Текущий уровень топлива: {fuelLevel} литров.");
    }

    public void Start()
    {
        if (fuelLevel > 0)
        {
            isRunning = true;
            Console.WriteLine("Автомобиль заведен.");
        }
        else
        {
            Console.WriteLine("Нет топлива. Заправьтесь перед поездкой.");
        }
    }

    public void Drive(double distance)
    {
        if (isRunning)
        {
            double fuelNeeded = distance * fuelConsumption;

            if (fuelLevel >= fuelNeeded)
            {
                fuelLevel -= fuelNeeded;
                Console.WriteLine($"Проехали {distance} км. Осталось топлива: {fuelLevel} литров.");

                // Обновляем общий пробег
                mileage += distance;
            }
            else
            {
                Console.WriteLine("Недостаточно топлива. Необходимо заправиться.");
            }
        }
        else
        {
            Console.WriteLine("Автомобиль не заведен. Заведите авто перед поездкой.");
        }
    }

    public void Brake()
    {
        if (isRunning)
        {
            Console.WriteLine("Выполнено торможение.");
        }
        else
        {
            Console.WriteLine("Автомобиль не заведен. Заведите авто, прежде чем тормозить.");
        }
    }

    public void Accelerate()
    {
        if (isRunning)
        {
            Console.WriteLine("Ускорение выполнено.");
        }
        else
        {
            Console.WriteLine("Автомобиль не заведен. Заведите авто, прежде чем разгоняться.");
        }
    }

    public double CalculateDistance(double startX, double startY, double endX, double endY)
    {
        double distance = Math.Sqrt(Math.Pow(endX - startX, 2) + Math.Pow(endY - startY, 2));
        return distance;
    }

    public double GetTotalMileage()
    {
        return mileage;
    }

    public void Accident(Car[] cars)
    {
        if (cars.Length > 0)
        {
            Random random = new Random();
            int carIndex = random.Next(0, cars.Length);

            cars[carIndex].isRunning = false;
            Console.WriteLine($"Авария! Машина {carIndex + 1} вышла из строя.");
        }
        else
        {
            Console.WriteLine("Нет машин для аварии.");
        }
    }
}

class Program
{
    static void Main()
    {
        Car[] cars = new Car[3]; // Создаем массив из трех машин

        for (int i = 0; i < cars.Length; i++)
        {
            cars[i] = new Car();
        } 

        // Заполняем баки, запускаем машины и выполняем действия

        cars[0].FillTank();
        cars[0].Start();
        cars[0].Drive(440);

        cars[1].FillTank();
        cars[1].Start();
        cars[1].Drive(550);

        cars[2].FillTank();
        cars[2].Start();
        cars[2].Drive(660);

        // Вызываем метод аварии
        cars[0].Accident(cars);

        Console.WriteLine($"Общий пробег для машины 1: {cars[0].GetTotalMileage()} км");
        Console.WriteLine($"Общий пробег для машины 2: {cars[1].GetTotalMileage()} км");
        Console.WriteLine($"Общий пробег для машины 3: {cars[2].GetTotalMileage()} км");
    }
}