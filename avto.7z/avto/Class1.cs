﻿
using System;

class Avto
{
    private string carNumber;
    private int fuelInTank;
    private double fuelConsumption;

    public Avto(string carNumber, int initialFuel, double consumption)
    {
        this.carNumber = carNumber;
        fuelInTank = initialFuel;
        fuelConsumption = consumption;
    }

    public void Info()
    {
        Console.WriteLine($"Номер автомобиля: {carNumber}");
        Console.WriteLine($"Количество бензина в баке: {fuelInTank} литров");
        Console.WriteLine($"Расход топлива на 100 км: {fuelConsumption} литров");
    }

    public void Our()
    {
        Console.WriteLine("Информация о машине:");
        Info();
    }

    public void Zapravka(int fuelToAdd)
    {
        fuelInTank += fuelToAdd;
        Console.WriteLine($"Бак заправлен. Текущий уровень топлива: {fuelInTank} литров.");
    }

    public int Ostatok()
    {
        return fuelInTank;
    }
}
